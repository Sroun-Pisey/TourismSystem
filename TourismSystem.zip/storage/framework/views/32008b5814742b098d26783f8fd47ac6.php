<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Posts List</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-success mb-3">+ Create New Post</a>

    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>Feather Image</th>
                <th style="width: 40%;">Title</th>
                <th>Customer</th>
                <th>Category</th>
                <th>Status</th>
                <th>Created At</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td style="width:100px;">
                    <?php if($post->feather_image): ?>
                        <img src="<?php echo e(asset('storage/' . $post->feather_image)); ?>" alt="Feather Image" class="img-fluid rounded" />
                    <?php else: ?>
                        <span>No Image</span>
                    <?php endif; ?>
                </td>
                <td><?php echo e($post->title); ?></td>
                <td><?php echo e($post->customer->name ?? 'N/A'); ?></td>
                <td><?php echo e($post->category->name ?? 'N/A'); ?></td>
                <td>
                    <?php if($post->status): ?>
                        <span class="badge bg-success">Published</span>
                    <?php else: ?>
                        <span class="badge bg-secondary">Unpublished</span>
                    <?php endif; ?>
                </td>
                <td><?php echo e($post->created_at->format('Y-m-d')); ?></td>
                <td>
                    <a href="<?php echo e(route('posts.show', $post->id)); ?>" class="btn btn-sm btn-primary" title="Show">
                        <i class="fas fa-eye"></i>
                    </a>

                    <a href="<?php echo e(route('posts.edit', $post->id)); ?>" class="btn btn-sm btn-warning" title="Edit">
                        <i class="fas fa-edit"></i>
                    </a>

                    <form style="display: inline;" action="<?php echo e(route('posts.destroy', $post->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this post?');">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-danger" title="Delete">
                            <i class="fas fa-trash-alt"></i>
                        </button>
                    </form>
                </td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="7" class="text-center">No posts found.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\DELL\Desktop\TourismSystem\resources\views\posts\index.blade.php ENDPATH**/ ?>