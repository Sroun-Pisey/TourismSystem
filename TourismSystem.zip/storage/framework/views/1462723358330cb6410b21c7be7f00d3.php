<?php $__env->startSection('content'); ?>

<div class="container" style="margin-top: 40px">
    <h2>Post Details</h2>

    <table class="table table-bordered">
        <tr>
            <th>ID</th>
            <td><?php echo e($post->id); ?></td>
        </tr>
        <tr>
            <th>Title</th>
            <td><?php echo e($post->title); ?></td>
        </tr>
        <tr>
            <th>Customer</th>
            <td><?php echo e($post->customer->name ?? 'N/A'); ?></td>
        </tr>
        <tr>
            <th>Category</th>
            <td><?php echo e($post->category->name ?? 'N/A'); ?></td>
        </tr>
        <tr>
            <th>Content</th>
            <td><?php echo e($post->content); ?></td>
        </tr>
        <tr>
            <th>Status</th>
            <td>
                <span class="badge <?php echo e($post->status ? 'bg-success' : 'bg-secondary'); ?>">
                    <?php echo e($post->status ? 'Published' : 'Draft'); ?>

                </span>
            </td>
        </tr>
        <tr>
            <th>Feather Image</th>
            <td>
                <?php if($post->feather_image): ?>
                    <img src="<?php echo e(asset('storage/' . $post->feather_image)); ?>" width="120" height="120" style="object-fit: cover; border: 1px solid #ccc;">
                <?php else: ?>
                    <img src="<?php echo e(asset('img/no_image.jpg')); ?>" width="120" height="120" style="object-fit: cover; border: 1px solid #ccc;">
                <?php endif; ?>
            </td>
        </tr>
    </table>

    <a href="<?php echo e(route('posts.index')); ?>" class="btn btn-secondary">Back to List</a>
    <a href="<?php echo e(route('posts.edit', $post->id)); ?>" class="btn btn-primary">Edit Post</a>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\DELL\Desktop\TourismSystem\resources\views\posts\show.blade.php ENDPATH**/ ?>