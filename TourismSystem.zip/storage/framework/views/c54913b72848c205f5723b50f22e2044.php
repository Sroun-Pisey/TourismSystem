<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Customer List</h3>
        <a href="<?php echo e(route('customers.create')); ?>" class="btn btn-success">+ Add New Customer</a>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="card" style="margin-top: 10px;">
        <div class="card-body p-0">
            <table class="table table-bordered table-striped mb-0">
                <thead class="table-dark">
                    <tr>
                        <th>#</th>
                        <th>Profile</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Status</th>
                        <th>Phone</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td>
                                <?php if($customer->profile_image): ?>
                                    <img src="<?php echo e(asset('storage/' . $customer->profile_image)); ?>" alt="Profile" width="40" height="40" class="rounded-circle">
                                <?php else: ?>
                                    <span class="text-muted">No image</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($customer->name); ?></td>
                            <td><?php echo e($customer->email); ?></td>
                            <td>
                                <span class="badge bg-<?php echo e($customer->status == 'active' ? 'success' : ($customer->status == 'banned' ? 'danger' : 'warning')); ?>">
                                    <?php echo e(ucfirst($customer->status)); ?>

                                </span>
                            </td>
                            <td><?php echo e($customer->phone ?? '-'); ?></td>
                            <td><?php echo e($customer->created_at->format('Y-m-d')); ?></td>
                            <td>

                                <a href="<?php echo e(route('customers.edit', $customer->id)); ?>" class="btn btn-sm btn-warning" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                
                            <form class="delete-form d-inline" style="display: inline;" data-id="<?php echo e($customer->id); ?>" action="<?php echo e(route('customers.destroy', $customer->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="button" class="btn btn-sm btn-danger delete-button" title="Delete">
                                    <i class="fas fa-trash-alt"></i>
                                </button>
                            </form>

                                <script>
                                    document.addEventListener('DOMContentLoaded', function () {
                                        const deleteButtons = document.querySelectorAll('.delete-button');

                                        deleteButtons.forEach(button => {
                                            button.addEventListener('click', function () {
                                                const form = this.closest('.delete-form');

                                                Swal.fire({
                                                    title: 'Are you sure?',
                                                    text: "This action cannot be undone.",
                                                    icon: 'warning',
                                                    showCancelButton: true,
                                                    confirmButtonColor: '#d33',
                                                    cancelButtonColor: '#6c757d',
                                                    confirmButtonText: 'Yes, delete it!',
                                                    cancelButtonText: 'Cancel'
                                                }).then((result) => {
                                                    if (result.isConfirmed) {
                                                        form.submit();
                                                    }
                                                });
                                            });
                                        });
                                    });
                                </script>

                            </td>


                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center text-muted">No customers found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\DELL\Desktop\TourismSystem\resources\views\customers\index.blade.php ENDPATH**/ ?>